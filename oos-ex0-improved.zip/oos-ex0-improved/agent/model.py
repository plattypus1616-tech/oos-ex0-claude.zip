#!/usr/bin/env python3
"""
oos_decision_model.py - Model keputusan final untuk "Shopify OOS & AI Outreach Auditor"

Pertanyaan: dari toko-toko hasil audit, mana yang layak di-pitch, berapa banyak, dan
strategi apa yang paling tahan banting di semua skenario (A-Z)?

Layer:
 1. First principles : SKU = proses 2-state (in-stock <-> OOS). pi = lam/(lam+mu).
                       Snapshot k/n -> posterior Beta(1+k, 1+n-k).
 2. Entropi          : (a) diffuseness OOS lintas kategori (struktural vs terkonsentrasi)
                       (b) entropi diferensial posterior -> prioritas re-audit
 3. Second-order     : OOS != masalah. Rantai: tidak sengaja? -> belum punya tool? ->
                       cukup parah? -> balas? -> closing?
 4. Survival         : (a) hazard restock dari snapshot berulang (MLE eksponensial + censoring)
                       (b) domain pengirim "mati" bila strike (spam/bounce) >= B
 5. Game theory      : matriks payoff strategi x skenario -> maximin, minimax regret,
                       strategi campuran optimal (LP zero-sum vs "alam")
 6. Monte Carlo      : semua parameter = distribusi, bukan angka tunggal

Aturan besi: input hanya FAKTA audit (n, k, judul varian, kategori). Tidak ada estimasi
nominal kerugian toko target. Payoff dalam "deal-equivalent" (D), bukan mata uang.
Semua parameter bertanda ASUMSI harus dikalibrasi dengan funnel outreach milik sendiri.

Pakai:  python oos_decision_model.py                 # selftest + skenario A-Z + game
        python oos_decision_model.py --audits a.json # ranking toko nyata (array StoreAuditResult)
"""
import argparse, json, re
from dataclasses import dataclass, replace
import numpy as np
from scipy.stats import beta as beta_dist
from scipy.optimize import linprog

# ---------------------------------------------------------------- konstanta model
PI0 = 0.08                 # OOS rate di mana "keparahan" = 50% (ASUMSI; 1% OOS itu noise)
UNINT_ASSUMED = 0.45       # keyakinan pengirim: P(OOS tidak disengaja) (ASUMSI)
TOOL_ASSUMED = 0.30        # keyakinan pengirim: P(toko sudah punya back-in-stock) (ASUMSI)
W_DIFFUSE, W_CORE = 1.2, 0.9   # bobot logit fitur second-order (ASUMSI; kalibrasi dari hasil)
KAPPA = 6.0                # konsentrasi Beta antar-toko (kecil = heterogen)
CORE = {"s", "m", "l"}
SIZE = re.compile(r"^(xxs|xs|s|m|l|xl|xxl|2xl|3xl|4xl)$", re.I)

expit = lambda x: 1 / (1 + np.exp(-x))
logit = lambda p: np.log(p / (1 - p))


# ---------------------------------------------------------------- 1. first principles
def oos_posterior(k, n, a0=1.0, b0=1.0):
    """Posterior Beta untuk pi = P(OOS stasioner) dari 1 snapshot."""
    return a0 + k, b0 + n - k

def restock_posterior(spells, a0=1.0, b0=10.0):
    """spells: [(durasi_hari, restocked_bool)]. Prior Gamma pada mu (per hari); mean prior 0.1/hari.
    Right-censoring ditangani: spell yang belum selesai menambah exposure tanpa menambah event."""
    ev = sum(1 for _, r in spells if r)
    expo = sum(d for d, _ in spells)
    return a0 + ev, b0 + expo            # Gamma(shape, rate)

def stockout_hazard(pi, mu):
    """lam = mu * pi / (1 - pi)  (balikan dari pi = lam / (lam + mu))."""
    return mu * pi / (1 - pi)


# ---------------------------------------------------------------- 2. entropi
def diffuseness(categories):
    """Entropi Shannon ternormalisasi H/log(m) dari sebaran OOS lintas kategori.
    Tinggi = tersebar (indikasi proses replenishment); rendah = terkonsentrasi (indikasi drop/discontinue).
    None bila tidak informatif (satu kategori / semua 'General')."""
    cats = [c or "General" for c in categories]
    vals, cnt = np.unique(cats, return_counts=True)
    if len(vals) < 2:
        return None
    p = cnt / cnt.sum()
    return float(-(p * np.log(p)).sum() / np.log(len(vals)))

def core_share(variant_titles):
    """Porsi OOS di ukuran inti (S/M/L) di antara varian yang ukurannya terbaca. Ukuran ujung
    (XS, XXL, dst) habis itu wajar (ekor size curve); ukuran inti habis = demand > supply."""
    toks = []
    for t in variant_titles:
        for tok in re.split(r"[\s/|-]+", t or ""):
            if SIZE.match(tok):
                toks.append(tok.lower()); break
    return sum(t in CORE for t in toks) / len(toks) if len(toks) >= 3 else None

def reaudit_priority(k, n):
    """Entropi diferensial posterior: makin tinggi = makin tidak pasti = layak di-audit ulang."""
    return float(beta_dist(*oos_posterior(k, n)).entropy())


# ---------------------------------------------------------------- 3. second-order
def unint_mean(d, c, base=UNINT_ASSUMED):
    """P(OOS tidak disengaja) dari fitur entropi & size-curve. d,c dalam [0,1]; netral = 0.5."""
    return expit(logit(base) + W_DIFFUSE * (d - 0.5) + W_CORE * (c - 0.5))

def severity(pi_hat):
    return pi_hat / (pi_hat + PI0)

def pitch_score(k, n, d=0.5, c=0.5):
    """Skor relevansi pitch (0..1) dari fakta audit; dipakai untuk ranking. k==0 -> -1 (tak ada bukti)."""
    d = 0.5 if d is None else d
    c = 0.5 if c is None else c
    s = unint_mean(d, c) * (1 - TOOL_ASSUMED) * severity((1 + k) / (2 + n))
    return np.where(np.asarray(k) > 0, s, -1.0)


# ---------------------------------------------------------------- parameter & skenario
@dataclass
class Params:
    pool_n: float = 60       # jumlah toko teraudit per kampanye
    pool_oos: float = 0.15   # rata-rata OOS rate antar toko (ASUMSI)
    unint: float = 0.45      # P(OOS tidak disengaja) sebenarnya (ASUMSI)
    tool: float = 0.30       # P(sudah punya tool back-in-stock) sebenarnya (ASUMSI)
    reply_rel: float = 0.05  # P(balas | relevan)  (ASUMSI; benchmark vendor: 1.5-3% rata-rata, 4-5% targeted)
    reply_irr: float = 0.008 # P(balas | tak relevan): penolakan sopan, tanpa deal
    close: float = 0.20      # P(closing | balas & relevan) (ASUMSI)
    strike: float = 0.001    # P(spam-complaint/hard-bounce | kirim, relevan). Anchor: Gmail <0.10%
    gamma_irr: float = 6.0   # pengganda strike untuk email tak relevan (ASUMSI)
    rho: float = 0.6         # seberapa informatif skor terhadap kebenaran (1 = sempurna)
    deal: float = 1.0        # nilai 1 deal (satuan D)
    cost: float = 0.002      # biaya per kirim (D)  (ASUMSI; waktu personalisasi)
    B: int = 2               # anggaran strike sebelum domain "mati" (B=1 = pembacaan paling ketat)
    L_ruin: float = 3.0      # kerugian bila domain mati (D)

PROB_FIELDS = ("pool_oos", "unint", "tool", "reply_rel", "reply_irr", "close", "strike", "rho")

def apply(p, mult):
    kw = {}
    for f, m in mult.items():
        v = getattr(p, f) * m
        kw[f] = min(max(v, 1e-4), 0.98) if f in PROB_FIELDS else (max(5, round(v)) if f == "pool_n" else v)
    return replace(p, **kw)

def merge(*ms):
    out = {}
    for m in ms:
        for k, v in m.items():
            out[k] = out.get(k, 1.0) * v
    return out

_base = {
    "B": ("Toko high-pain (OOS tidak disengaja, tanpa tool)", {"unint": 1.5, "tool": 0.5}),
    "C": ("Mayoritas OOS disengaja (model drop/scarcity)", {"unint": 0.4}),
    "D": ("Kompetitor sudah pitch toko yang sama", {"reply_rel": 0.5, "reply_irr": 0.5, "close": 0.7}),
    "E": ("Adopsi tool back-in-stock tinggi", {"tool": 2.0}),
    "F": ("Reputasi domain memburuk", {"strike": 3.0}),
    "G": ("Domain bersih & hangat", {"strike": 0.4}),
    "H": ("Musim puncak (BFCM): OOS naik, owner sibuk", {"pool_oos": 1.5, "reply_rel": 0.6, "reply_irr": 0.6}),
    "I": ("Low season: OOS turun, owner longgar", {"pool_oos": 0.7, "reply_rel": 1.3, "reply_irr": 1.3}),
    "J": ("Guncangan supply chain", {"pool_oos": 1.8, "unint": 1.3, "reply_rel": 0.8}),
    "K": ("Toko kecil: cepat balas, budget tipis", {"reply_rel": 1.3, "close": 0.6, "deal": 0.5}),
    "L": ("Toko besar: lambat, closing besar, sudah punya tool", {"reply_rel": 0.6, "close": 1.4, "deal": 2.5, "tool": 1.5}),
    "M": ("Kontak generik (support@)", {"reply_rel": 0.5, "reply_irr": 0.5, "strike": 1.5}),
    "N": ("Kontak langsung founder", {"reply_rel": 1.8, "strike": 0.7}),
    "O": ("Personalisasi video (Loom)", {"reply_rel": 1.6, "close": 1.2, "cost": 3.0}),
    "P": ("Template generik", {"reply_rel": 0.6, "strike": 2.0}),
    "Q": ("Klaim dilebih-lebihkan (loss/revenue)", {"reply_rel": 1.3, "strike": 3.5, "close": 0.5}),
    "R": ("Facts-only jujur (aturan app saat ini)", {"close": 1.1, "strike": 0.8}),
    "S": ("Data noisy: pre-order/continue-selling terbaca OOS", {"unint": 0.6, "rho": 0.5}),
    "T": ("Katalog diblok bot protection", {"pool_n": 0.4}),
    "U": ("Penegakan anti-spam mengetat", {"strike": 2.0, "reply_rel": 0.8}),
    "V": ("Perang harga / ACV rendah", {"deal": 0.4, "close": 0.8}),
    "W": ("Siklus penjualan panjang (closing lewat horizon)", {"close": 0.6}),
    "X": ("Warm referral / intro", {"reply_rel": 2.5, "reply_irr": 1.5, "close": 1.5, "strike": 0.5, "pool_n": 0.3}),
}
SCEN = {"A": ("Baseline (prior)", {})}
SCEN.update(_base)
SCEN["Y"] = ("Perfect storm (C+D+E+F)", merge(_base["C"][1], _base["D"][1], _base["E"][1], _base["F"][1]))
SCEN["Z"] = ("Dream case (B+G+N+O)", merge(_base["B"][1], _base["G"][1], _base["N"][1], _base["O"][1]))
STRESS = {"Y", "Z"}   # dipakai di maximin/regret, tidak masuk rata-rata Bayes

STRATS = {"SKIP": None, "TOP15": 0.15, "TOP30": 0.30, "TOP60": 0.60, "SPRAY": 1.0}


# ---------------------------------------------------------------- 6. Monte Carlo
def simulate(strategy, p, N=10000, seed=7):
    """Satu kampanye = pool M toko. Kembalikan U (utility per path), deals, sends, ruin.
    Seed sama antar strategi/skenario -> common random numbers (perbandingan berpasangan)."""
    rng = np.random.default_rng(seed)
    M = int(p.pool_n)
    sh = (N, M)
    n = np.clip(rng.lognormal(np.log(120), 0.9, sh), 10, 2500).astype(int)
    pi = rng.beta(p.pool_oos * KAPPA, (1 - p.pool_oos) * KAPPA, sh)
    k = rng.binomial(n, pi)
    d, c = rng.beta(4, 4, sh), rng.beta(4, 4, sh)
    u_unint, u_tool, u_sev, u_rep, u_close, u_strk = (rng.random(sh) for _ in range(6))

    # kebenaran (tak terlihat pengirim)
    m_true = p.rho * unint_mean(d, c, p.unint) + (1 - p.rho) * p.unint
    rel = (u_unint < m_true) & (u_tool >= p.tool) & (u_sev < severity(pi))
    # pandangan pengirim (hanya fakta audit + asumsi)
    score = pitch_score(k, n, d, c)

    if strategy == "SKIP":
        return dict(U=np.zeros(N), deals=np.zeros(N), sends=np.zeros(N), ruin=np.zeros(N, bool))
    q = STRATS[strategy]
    if q >= 1.0:
        send, order = k > 0, np.tile(np.arange(M), (N, 1))          # urutan acak
    else:
        thr = np.quantile(score, 1 - q, axis=1, keepdims=True)
        send, order = (score >= thr) & (k > 0), np.argsort(-score, axis=1)  # terbaik dulu
    g = lambda a: np.take_along_axis(a, order, axis=1)
    send, rel, u_rep, u_close, u_strk = g(send), g(rel), g(u_rep), g(u_close), g(u_strk)

    reply = u_rep < np.where(rel, p.reply_rel, p.reply_irr)
    deal = reply & rel & (u_close < p.close)
    strike = send & (u_strk < np.where(rel, p.strike, p.strike * p.gamma_irr))
    cs = np.cumsum(strike, axis=1)
    alive = (cs - strike) < p.B                    # domain masih hidup saat email ini dikirim
    deals = (deal & send & alive).sum(1)
    sends = (send & alive).sum(1)
    ruin = cs[:, -1] >= p.B
    U = p.deal * deals - p.cost * sends - p.L_ruin * ruin
    return dict(U=U, deals=deals, sends=sends, ruin=ruin)

def summarize(r):
    U = r["U"]; lo = np.sort(U)[: max(1, len(U) // 20)]
    return dict(EV=U.mean(), SE=U.std(ddof=1) / np.sqrt(len(U)), P_pos=(U > 0).mean(),
                CVaR5=lo.mean(), P_ruin=r["ruin"].mean(), deals=r["deals"].mean(), sends=r["sends"].mean())

def run_grid(base=Params(), N=10000, seed=7):
    res = {}
    for s, (name, mult) in SCEN.items():
        p = apply(base, mult)
        for st in STRATS:
            res[(s, st)] = summarize(simulate(st, p, N, seed))
    return res


# ---------------------------------------------------------------- 5. game theory
def game(res):
    S, T = list(SCEN), list(STRATS)
    U = np.array([[res[(s, t)]["EV"] for t in T] for s in S])
    bayes_rows = [i for i, s in enumerate(S) if s not in STRESS]
    out = {"U": U, "S": S, "T": T}
    out["maximin"] = T[int(np.argmax(U.min(axis=0)))]
    out["minimax_regret"] = T[int(np.argmin((U.max(axis=1, keepdims=True) - U).max(axis=0)))]
    out["bayes"] = T[int(np.argmax(U[bayes_rows].mean(axis=0)))]
    out["bayes_ev"] = U[bayes_rows].mean(axis=0)
    # strategi campuran maximin: max v s.t. sum_j x_j U[s,j] >= v utk semua s
    J = len(T)
    A = np.hstack([-U, np.ones((len(S), 1))])
    r = linprog(c=[0] * J + [-1], A_ub=A, b_ub=np.zeros(len(S)),
                A_eq=[[1] * J + [0]], b_eq=[1], bounds=[(0, 1)] * J + [(None, None)])
    out["mix"] = dict(zip(T, np.round(r.x[:J], 3))); out["mix_value"] = r.x[J]
    return out


def sensitivity(strategy="TOP30", base=Params(), N=10000, seed=7):
    """Tornado satu-per-satu: tiap asumsi x0.5 dan x1.5 -> EV strategi (common random numbers)."""
    ev = lambda p: summarize(simulate(strategy, p, N, seed))["EV"]
    rows = [(f, ev(apply(base, {f: 0.5})), ev(apply(base, {f: 1.5}))) for f in
            ("reply_rel", "close", "cost", "deal", "unint", "tool", "strike", "rho", "pool_oos", "pool_n")]
    rows.sort(key=lambda r: -abs(r[2] - r[1]))
    return ev(base), rows

def breakeven_reply(strategy="TOP30", base=Params(), N=10000, seed=7):
    """P(balas | relevan) minimum agar EV strategi > 0 (bisection; EV naik monoton terhadap reply)."""
    lo, hi = base.reply_rel * 0.2, base.reply_rel * 5
    for _ in range(18):
        mid = (lo + hi) / 2
        if summarize(simulate(strategy, replace(base, reply_rel=mid), N, seed))["EV"] > 0: hi = mid
        else: lo = mid
    return (lo + hi) / 2


# ---------------------------------------------------------------- data nyata dari app
def rank_real(audits, q_star=0.30):
    """audits: array StoreAuditResult (JSON dari app). Catatan: soldOutProducts di app dipotong
    50 item teratas berdasarkan harga -> fitur entropi/size-curve bias ke item mahal."""
    rows = []
    for a in audits:
        n, k = a.get("totalVariantsScanned", 0), a.get("soldOutCount", 0)
        if n <= 0:
            continue
        items = a.get("soldOutProducts", [])
        d = diffuseness([i.get("productType") for i in items])
        c = core_share([i.get("variantTitle") for i in items])
        lo, hi = beta_dist.ppf([0.05, 0.95], *oos_posterior(k, n))
        rows.append(dict(store=a.get("cleanDomain"), n=n, k=k, oos=k / n, lo=lo, hi=hi,
                         diffuse=d, core=c, score=float(pitch_score(k, n, d, c)),
                         H_post=reaudit_priority(k, n)))
    rows.sort(key=lambda r: -r["score"])
    cut = max(1, int(np.ceil(q_star * len(rows))))
    for i, r in enumerate(rows):
        r["action"] = "PITCH" if (i < cut and r["k"] > 0) else ("RE-AUDIT" if r["H_post"] > -2.0 and r["k"] > 0 else "SKIP")
    return rows


# ---------------------------------------------------------------- selftest (validasi sebelum dipercaya)
def selftest():
    ok = True
    def chk(name, cond, info=""):
        nonlocal ok; ok &= bool(cond); print(f"  [{'OK' if cond else 'GAGAL'}] {name} {info}")
    rng = np.random.default_rng(1)
    # 1. cakupan CI Beta 90% (n kecil-menengah)
    hit = 0; T = 4000
    for _ in range(T):
        pi = rng.beta(1.5, 8); n = int(rng.integers(20, 400)); k = rng.binomial(n, pi)
        lo, hi = beta_dist.ppf([0.05, 0.95], *oos_posterior(k, n)); hit += lo <= pi <= hi
    chk("CI posterior 90% mencakup pi sebenarnya", abs(hit / T - 0.90) < 0.03, f"(cakupan={hit/T:.3f}, prior sedikit beda dari Beta(1,1) -> toleransi 3pp)")
    # 2. pemulihan mu dari spell tersensor
    mu = 0.10; dur = rng.exponential(1 / mu, 3000); cens = 30.0
    spells = [(min(x, cens), x <= cens) for x in dur]
    a, b = restock_posterior(spells, a0=0.01, b0=0.01)
    chk("MLE restock hazard pulih dengan censoring", abs(a / b - mu) < 0.005, f"(mu_hat={a/b:.4f}, benar={mu})")
    # 3. SKIP tepat 0
    chk("SKIP => U = 0", simulate("SKIP", Params(), 500)["U"].sum() == 0)
    # 4. analitik ruin: strike seragam s, B=1, m kirim -> 1-(1-s)^m
    s, m = 0.01, 40
    p = replace(Params(), pool_n=m, pool_oos=0.9, strike=s, gamma_irr=1.0, B=1, close=0.0)
    r = simulate("SPRAY", p, 20000, seed=3); emp = r["ruin"].mean(); ana = 1 - (1 - s) ** r["sends"].max()
    se = np.sqrt(emp * (1 - emp) / 20000)
    chk("P(ruin) MC cocok dengan 1-(1-s)^m", abs(emp - ana) < 3 * se + 0.01, f"(MC={emp:.3f}, analitik~{ana:.3f})")
    # 5. dua seed konsisten
    e1 = summarize(simulate("SPRAY", Params(), 10000, 11)); e2 = summarize(simulate("SPRAY", Params(), 10000, 22))
    chk("Dua seed konsisten (EV SPRAY)", abs(e1["EV"] - e2["EV"]) < 3 * np.hypot(e1["SE"], e2["SE"]), f"({e1['EV']:.4f} vs {e2['EV']:.4f})")
    # 6. monotonik: reply naik => deal naik
    lo_, hi_ = summarize(simulate("TOP30", Params(), 8000))["deals"], summarize(simulate("TOP30", replace(Params(), reply_rel=0.10), 8000))["deals"]
    chk("reply_rel x2 => deals naik", hi_ > lo_, f"({lo_:.3f} -> {hi_:.3f})")
    # 7. semua probabilitas skenario dalam [0,1]
    bad = [s for s, (_, mu_) in SCEN.items() if any(not 0 <= getattr(apply(Params(), mu_), f) <= 1 for f in PROB_FIELDS)]
    chk("Probabilitas semua skenario valid", not bad, str(bad))
    chk("Jumlah skenario = 26", len(SCEN) == 26)
    return ok


# ---------------------------------------------------------------- CLI
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--audits"); ap.add_argument("--paths", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=7); ap.add_argument("--csv", default="scenario_results.csv")
    ap.add_argument("--skip-selftest", action="store_true"); ap.add_argument("--sensitivity", action="store_true")
    a = ap.parse_args()

    if a.audits:
        for r in rank_real(json.load(open(a.audits))):
            f = lambda x: "  -  " if x is None else f"{x:.2f}"
            print(f"{r['store']:<28} n={r['n']:<5} k={r['k']:<4} OOS={r['oos']:.1%} [{r['lo']:.1%},{r['hi']:.1%}] "
                  f"diffuse={f(r['diffuse'])} core={f(r['core'])} score={r['score']:.3f} -> {r['action']}")
        return

    if not a.skip_selftest:
        print("SELFTEST"); assert selftest(), "selftest gagal - hentikan"
    res = run_grid(Params(), a.paths, a.seed)
    G = game(res)
    print("\nSKENARIO A-Z (EV dalam deal-equivalent D per kampanye; ruin = domain mati)")
    print(f"{'':2}{'skenario':<52}" + "".join(f"{t:>8}" for t in STRATS) + "  terbaik  ruin30 ruinSPR")
    for s, (name, _) in SCEN.items():
        evs = {t: res[(s, t)]["EV"] for t in STRATS}; best = max(evs, key=evs.get)
        print(f"{s:2}{name:<52}" + "".join(f"{evs[t]:8.3f}" for t in STRATS) + f"  {best:<8}{res[(s, 'TOP30')]['P_ruin']:6.1%}{res[(s, 'SPRAY')]['P_ruin']:7.1%}")
    print("\nGAME THEORY (strategi pengirim vs skenario sebagai 'alam')")
    print("  EV rata-rata Bayes (A-X):", {t: round(float(v), 3) for t, v in zip(G['T'], G['bayes_ev'])})
    print("  Bayes:", G["bayes"], "| Maximin:", G["maximin"], "| Minimax regret:", G["minimax_regret"])
    print("  Campuran maximin optimal:", {t: float(v) for t, v in G["mix"].items()}, "nilai:", round(float(G["mix_value"]), 4))
    if a.sensitivity:
        e0, rows = sensitivity(N=a.paths, seed=a.seed)
        print(f"\nSENSITIVITAS TOP30 @ baseline (EV={e0:.4f} D): asumsi x0.5 | x1.5")
        for f_, lo_, hi_ in rows:
            print(f"  {f_:<10}{lo_:8.4f} |{hi_:8.4f}")
        for st in ("TOP15", "TOP30"):
            print(f"  break-even P(balas|relevan) {st}: {breakeven_reply(st, N=a.paths, seed=a.seed):.3f} (asumsi {Params().reply_rel})")
        G1 = game(run_grid(replace(Params(), B=1), a.paths, a.seed))
        print(f"  Jika B=1 (ruin paling ketat): Bayes={G1['bayes']} Maximin={G1['maximin']} Regret={G1['minimax_regret']}")
    with open(a.csv, "w") as f:
        f.write("scenario,name,strategy,EV,SE,P_pos,CVaR5,P_ruin,deals,sends\n")
        for (s, t), v in res.items():
            f.write(f"{s},\"{SCEN[s][0]}\",{t},{v['EV']:.5f},{v['SE']:.5f},{v['P_pos']:.4f},{v['CVaR5']:.4f},{v['P_ruin']:.4f},{v['deals']:.4f},{v['sends']:.2f}\n")
    print("\nDisimpan:", a.csv)

if __name__ == "__main__":
    main()
