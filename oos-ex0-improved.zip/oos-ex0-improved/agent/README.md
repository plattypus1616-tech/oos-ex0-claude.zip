# oos-agent - pipeline OOS outreach, 100% gratis, tanpa klik setelah setup

Alur harian (GitHub Actions): baca inbox -> gerbang keselamatan -> audit toko baru -> pilih TOP-30% (model) ->
draf (Gemini free tier, divalidasi anti-angka-karangan) -> kirim (batas harian) -> laporan Telegram.

## Setup satu kali (HP/laptop)
1. Buat repo **PRIVATE** di GitHub, upload isi folder ini (state/ berisi data lead).
2. Gemini API key dari AI Studio -> secret `GEMINI_API_KEY`.
3. Gmail KHUSUS pengirim (bukan akun utama), aktifkan 2FA, buat App Password -> secret `GMAIL_USER`, `GMAIL_APP_PASSWORD`.
4. Secret `SENDER_NAME` dan `SENDER_ADDRESS` (alamat pos bisnis; wajib di footer).
5. Telegram: chat @BotFather -> /newbot -> secret `TELEGRAM_TOKEN`; kirim pesan ke bot, lalu buka
   `https://api.telegram.org/bot<TOKEN>/getUpdates` -> ambil `chat.id` -> secret `TELEGRAM_CHAT_ID`.
6. Settings > Secrets and variables > Actions > Variables: `MODE=dry` (awal), `GEMINI_MODEL` sesuai di AI Studio.
7. Actions > oos-agent > Run workflow (tes pertama). Setelah itu jalan sendiri Senin-Jumat.

## Kontrol dari HP (Telegram)
`add namatoko.com` | `pause` | `resume`

## Naik tahap
- Minggu 1-2: `MODE=dry`, cek draf di `state/leads.csv` + laporan Telegram.
- Lalu `MODE=send`, `DAILY_CAP=5`. Naikkan pelan-pelan hanya jika bounce rendah.
- Gerbang otomatis: komplain >= STRIKE_BUDGET, bounce > 5%, atau kalibrasi balasan positif (lihat config.py).

## Tes lokal (tanpa internet/kunci)
`pip install -r requirements.txt && python -m tests.test_pipeline`

## Model keputusan
`python -m agent.model --sensitivity` (Monte Carlo 26 skenario) | `python -m agent.model --audits state_audits.json`
