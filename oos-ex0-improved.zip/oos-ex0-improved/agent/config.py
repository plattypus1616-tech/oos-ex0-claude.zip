import os

def _f(k, d): return float(os.getenv(k, d))
def _i(k, d): return int(os.getenv(k, d))

MODE = os.getenv("MODE", "dry")                 # dry = tidak kirim apa pun | send = kirim sungguhan
DAILY_CAP = _i("DAILY_CAP", 5)                  # maks email/hari (inbox baru: mulai kecil)
AUDIT_PER_RUN = _i("AUDIT_PER_RUN", 15)
PITCH_QUANTILE = _f("PITCH_QUANTILE", 0.30)     # hasil model: TOP15-TOP30 terbaik
MIN_POOL = _i("MIN_POOL", 10)                   # jangan pilih "top %" dari pool yang terlalu kecil
GENERIC_PENALTY = _f("GENERIC_PENALTY", 0.5)    # skenario M model: kontak generik
STRIKE_BUDGET = _i("STRIKE_BUDGET", 1)          # B=1 (paling ketat) -> pause di komplain pertama
BOUNCE_MAX = _f("BOUNCE_MAX", 0.05)             # ASUMSI: pause bila hard-bounce > 5% (min 10 kirim)
POSITIVE_REPLY_FLOOR = _f("POSITIVE_REPLY_FLOOR", 0.012)  # dari titik impas model (~1.1-1.4% per kirim)
CAL_MIN_SENDS = _i("CAL_MIN_SENDS", 60)
CAL_THRESHOLD = _f("CAL_THRESHOLD", 0.10)       # pause bila P(laju>=floor) < 10% setelah >=60 kirim
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")  # samakan dengan yang tampil di AI Studio
SEND_DELAY = _f("SEND_DELAY", 45)               # detik antar email
