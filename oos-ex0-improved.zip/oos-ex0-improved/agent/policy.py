"""Umpan balik model: hasil NYATA (kirim, balasan positif) -> posterior -> Monte Carlo -> kebijakan.
Memilih TOP15/TOP30/TOP60/SKIP dengan EV tertinggi; SKIP bila tidak ada yang EV > 0."""
from dataclasses import replace
from . import model

R_SEL = 0.25                 # porsi email relevan di antara yang terkirim (model OOS)
Q_PRIOR = (1.25, 98.75)      # prior Beta: ~1,25% balasan-positif per kirim (= titik impas model)
MIN_SENDS = 20               # di bawah ini data terlalu sedikit: pakai prior (TOP30)

def posterior_reply_rel(sends, positives):
    a, b = Q_PRIOR
    q = (a + positives) / (a + b + sends)
    return min(max(q / R_SEL, 1e-3), 0.5)

def decide(sends, positives, N=4000, seed=7):
    if sends < MIN_SENDS:
        return {"strategy": "TOP30", "quantile": 0.30, "ev": None, "note": f"kirim {sends} < {MIN_SENDS}: pakai prior"}
    p = replace(model.Params(), reply_rel=posterior_reply_rel(sends, positives))
    ev = {s: float(model.summarize(model.simulate(s, p, N, seed))["EV"]) for s in ("SKIP", "TOP15", "TOP30", "TOP60")}
    best = max(ev, key=ev.get)
    return {"strategy": best, "quantile": model.STRATS[best] or 0.0, "ev": ev,
            "note": f"posterior reply_rel={p.reply_rel:.3f} dari {positives}/{sends}"}
