# Perubahan atas kode asli (semua terverifikasi: tsc bersih, 3 tes TS + 10 tes Python)

| Area | Perubahan | File |
|---|---|---|
| Keamanan | Semua fetch ke toko lewat `safeFetch`: https saja, host harus publik (blok IP privat, localhost, metadata cloud), redirect divalidasi ulang, batas ukuran 5 MB | lib/safe-fetch.ts, app/api/audit/route.ts |
| Keamanan | Batas laju per IP, cek same-origin, batas ukuran body, batas panjang/jumlah input `generate-email` | lib/guards.ts, kedua route |
| Transparansi | Hapus estimasi kerugian (harga x unit/hari x 30), harga cadangan 45, dan "Estimasi Potensi Penjualan Terlewat" dari prompt email; kolom CSV dan label UI ikut dihapus | route.ts, generate-email/route.ts, VisualTriageZone.tsx, types.ts |
| Kualitas data | Kontak dipilih dengan peringkat (langsung > generik) dan wajib cocok domain; sebelumnya email pertama yang lolos filter | lib/contacts.ts |
| Aksesibilitas | 63 teks 9-11px dinaikkan ke 12px (text-xs) | app/, components/ |
| Konfigurasi | Nama model Gemini dari env `GEMINI_MODEL` | kedua route |
| Otomasi gratis | `agent/` + GitHub Actions: audit -> model -> draf -> kirim (batas harian) -> baca balasan -> kebijakan baru; laporan dan kontrol via Telegram | agent/, .github/workflows/agent.yml |
| Model | `agent/policy.py` memperbarui posterior dari hasil nyata lalu Monte Carlo memilih TOP15/30/60 atau SKIP | agent/policy.py, agent/model.py, model/ |

## Belum dikerjakan
- Sapuan `aria-label` di tombol ikon, pemecahan `page.tsx` (692 baris) dan `StoreAuditCard.tsx` (651 baris).
- Logika audit masih ada di 3 tempat (route.ts, audit_script.py, PythonScriptModal); sumber tunggal belum dibuat.
- `trustScore: 94` pada email cadangan masih hardcoded (generate-email/route.ts) - angka karangan, sebaiknya dihapus.
- Rate limit in-memory per instance; autentikasi nyata belum ada.
- Redirect/DNS rebinding diuji dengan mock, belum dengan jaringan nyata.

## Tes
`npm install && npx tsc --noEmit && npm test` dan `pip install -r requirements-agent.txt && python -m unittest tests.test_agent`
Setup otomasi gratis: lihat langkah di agent/README (secret GEMINI_API_KEY, GMAIL_*, TELEGRAM_*; MODE=dry dulu).
